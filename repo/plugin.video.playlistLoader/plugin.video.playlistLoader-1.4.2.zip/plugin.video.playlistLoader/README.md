# Kodi-plugin.video.playlistLoader

Taking ownership of plugin.video.playlistLoader previously owned by Avigdork
See: https://github.com/avigdork/xbmc-avigdork/pull/8#issuecomment-416955692

- Added Youtube Support

Usage:
    * Just copy URL (the URL must be contain "https://www.youtube.com") 
